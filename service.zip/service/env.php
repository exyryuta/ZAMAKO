<?php 

$hostname = "localhost";
$username = "root";
$password = "";
$db_name = "";

$db = mysqli_connect($hostname, $username, $password, $db_name);

if ($db->connect_error) {
    echo "connect error 404";
    die("error");
}